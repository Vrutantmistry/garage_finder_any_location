let map;
let service;
let infowindow;
let userLocation;
let directionsService;
let userMarker;

function initMap() {
    infowindow = new google.maps.InfoWindow();
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer();

    // Try HTML5 geolocation
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                userLocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
                };

                map = new google.maps.Map(document.getElementById("map"), {
                    center: userLocation,
                    zoom: 15,
                });

                directionsRenderer.setMap(map); // Set the map for directions rendering

                // Add a blue marker for the user's live location
                userMarker = new google.maps.Marker({
                    position: userLocation,
                    map: map,
                    icon: "http://maps.google.com/mapfiles/ms/icons/blue-dot.png", // Blue marker
                    title: "Your Location",
                });

                // Find nearby garages
                findNearbyGarages(userLocation);
            },
            () => {
                handleLocationError(true, infowindow, map.getCenter());
            }
        );
    } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infowindow, map.getCenter());
    }
}

function findNearbyGarages(location) {
    const request = {
        location: location,
        radius: "5000", // Search within 5000 meters
        query: "car garage", // Search for car garages
    };

    service = new google.maps.places.PlacesService(map);
    service.textSearch(request, (results, status) => {
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            // Display all garages on the map
            results.forEach((place) => {
                createMarker(place);
            });
        } else {
            console.error("Places API request failed:", status);
        }
    });
}

function createMarker(place) {
    if (!place.geometry || !place.geometry.location) return;

    // Add a red marker for the garage location
    const marker = new google.maps.Marker({
        map,
        position: place.geometry.location,
        icon: "http://maps.google.com/mapfiles/ms/icons/red-dot.png", // Red marker
        title: place.name,
    });

    // Add click event to show details and route
    google.maps.event.addListener(marker, "click", () => {
        const content = `
            <div>
                <strong>${place.name}</strong><br>
                Rating: ${place.rating || "No rating"}<br>
                Address: ${place.formatted_address || "Address not available"}
            </div>
        `;
        infowindow.setContent(content);
        infowindow.open(map, marker);

        // Calculate and display the route to this garage
        calculateAndDisplayRoute(place.geometry.location);
    });
}

function calculateAndDisplayRoute(destination) {
    directionsService.route(
        {
            origin: userLocation,
            destination: destination,
            travelMode: google.maps.TravelMode.DRIVING,
        },
        (response, status) => {
            if (status === "OK") {
                directionsRenderer.setDirections(response); // Display the route on the map
            } else {
                console.error("Directions request failed due to " + status);
            }
        }
    );
}

function handleLocationError(browserHasGeolocation, infowindow, pos) {
    infowindow.setPosition(pos);
    infowindow.setContent(
        browserHasGeolocation
            ? "Error: The Geolocation service failed."
            : "Error: Your browser doesn't support geolocation."
    );
    infowindow.open(map);
}

document.getElementById("findGarage").addEventListener("click", initMap);
